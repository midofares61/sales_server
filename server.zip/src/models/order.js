import { DataTypes, Model } from 'sequelize';

export class OrderModel extends Model {}

export function initOrder(sequelize) {
  OrderModel.init({
    id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
    customer_name: { type: DataTypes.STRING, allowNull: false },
    phone: { type: DataTypes.STRING, allowNull: false },
    phone_two: { type: DataTypes.STRING },
    address: { type: DataTypes.STRING },
    city: { type: DataTypes.STRING },
    nameAdd: { type: DataTypes.STRING },
    nameEdit: { type: DataTypes.STRING },
    sells: { type: DataTypes.BOOLEAN, defaultValue: false },
    mandobe: { type: DataTypes.BOOLEAN, defaultValue: false },
    total: { type: DataTypes.DECIMAL(10, 2), allowNull: false, defaultValue: 0 },
    status: { type: DataTypes.ENUM('pending', 'accept', 'refuse', 'delay'), defaultValue: 'pending' },
    notes: { type: DataTypes.TEXT },
    mandobe_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true },
    marketer_id: { type: DataTypes.INTEGER.UNSIGNED, allowNull: true }
  }, {
    sequelize,
    modelName: 'Order',
    tableName: 'orders',
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: false
  });
  return OrderModel;
}


