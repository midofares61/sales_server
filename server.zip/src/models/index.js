import { Sequelize } from 'sequelize';
import { env } from '../config/index.js';

export const sequelize = new Sequelize(env.db.database, env.db.username, env.db.password, {
  host: env.db.host,
  port: env.db.port,
  dialect: 'mysql',
  logging: false
});

// Models import functions
import { initSupplier } from './supplier.js';
import { initProduct } from './product.js';
import { initMarketer } from './marketer.js';
import { initMandobe } from './mandobe.js';
import { initOrder } from './order.js';
import { initOrderDetail } from './orderDetail.js';
import { initUser } from './user.js';

// Initialize models
export const Supplier = initSupplier(sequelize);
export const Product = initProduct(sequelize);
export const Marketer = initMarketer(sequelize);
export const Mandobe = initMandobe(sequelize);
export const Order = initOrder(sequelize);
export const OrderDetail = initOrderDetail(sequelize);
export const User = initUser(sequelize);

// Associations
Supplier.hasMany(Product, { foreignKey: 'supplier_id', as: 'products' });
Product.belongsTo(Supplier, { foreignKey: 'supplier_id', as: 'supplier' });

Marketer.hasMany(Order, { foreignKey: 'marketer_id', as: 'orders' });
Order.belongsTo(Marketer, { foreignKey: 'marketer_id', as: 'marketer' });

Mandobe.hasMany(Order, { foreignKey: 'mandobe_id', as: 'orders' });
Order.belongsTo(Mandobe, { foreignKey: 'mandobe_id', as: 'mandobeUser' });

Order.hasMany(OrderDetail, { foreignKey: 'order_id', as: 'details', onDelete: 'CASCADE' });
OrderDetail.belongsTo(Order, { foreignKey: 'order_id', as: 'order' });

Product.hasMany(OrderDetail, { foreignKey: 'product_id', as: 'orderDetails' });
OrderDetail.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

export async function connectDatabase() {
  await sequelize.authenticate();
}


