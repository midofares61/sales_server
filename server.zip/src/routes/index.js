import { Router } from 'express';
import { authenticate, authorize } from '../middlewares/auth.js';
import { login } from '../controllers/auth.controller.js';
import { listSuppliers, createSupplier, updateSupplier, deleteSupplier } from '../controllers/suppliers.controller.js';
import { listProducts, createProduct, updateProduct, deleteProduct } from '../controllers/products.controller.js';
import { listMarketers, createMarketer, updateMarketer, deleteMarketer } from '../controllers/marketers.controller.js';
import { listMandobes, createMandobe, updateMandobe, deleteMandobe } from '../controllers/mandobes.controller.js';
import { listOrders, createOrder, updateOrder, deleteOrder } from '../controllers/orders.controller.js';

const router = Router();

// Auth
router.post('/auth/login', login);

// Suppliers
router.get('/suppliers', authenticate, listSuppliers);
router.post('/suppliers', authenticate, authorize('admin'), createSupplier);
router.put('/suppliers/:id', authenticate, authorize('admin'), updateSupplier);
router.delete('/suppliers/:id', authenticate, authorize('admin'), deleteSupplier);

// Products
router.get('/products', authenticate, listProducts);
router.post('/products', authenticate, authorize('admin'), createProduct);
router.put('/products/:id', authenticate, authorize('admin'), updateProduct);
router.delete('/products/:id', authenticate, authorize('admin'), deleteProduct);

// Marketers
router.get('/marketers', authenticate, listMarketers);
router.post('/marketers', authenticate, authorize('admin'), createMarketer);
router.put('/marketers/:id', authenticate, authorize('admin'), updateMarketer);
router.delete('/marketers/:id', authenticate, authorize('admin'), deleteMarketer);

// Mandobes
router.get('/mandobes', authenticate, listMandobes);
router.post('/mandobes', authenticate, authorize('admin'), createMandobe);
router.put('/mandobes/:id', authenticate, authorize('admin'), updateMandobe);
router.delete('/mandobes/:id', authenticate, authorize('admin'), deleteMandobe);

// Orders
router.get('/orders', authenticate, listOrders);
router.post('/orders', authenticate, authorize('admin', 'marketer'), createOrder);
router.put('/orders/:id', authenticate, authorize('admin', 'marketer'), updateOrder);
router.delete('/orders/:id', authenticate, authorize('admin'), deleteOrder);

export default router;


