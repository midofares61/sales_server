/** @type {import('sequelize-cli').Migration} */
const bcrypt = require('bcrypt');

module.exports = {
  async up(queryInterface) {
    const hash = await bcrypt.hash('admin123', 10);
    await queryInterface.bulkInsert('users', [{
      name: 'Admin',
      phone: '01000000000',
      password_hash: hash,
      role: 'admin'
    }]);
  },
  async down(queryInterface) {
    await queryInterface.bulkDelete('users', { phone: '01000000000' });
  }
};
