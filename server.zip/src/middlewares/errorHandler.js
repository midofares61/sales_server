export function errorHandler(err, req, res, next) {
  // eslint-disable-next-line no-console
  console.error(err);
  if (err.name === 'SequelizeValidationError') {
    return res.status(400).json({ message: 'Validation error', errors: err.errors.map(e => e.message) });
  }
  res.status(500).json({ message: 'Internal server error' });
}


