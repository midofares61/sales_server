import { Product, Supplier } from '../models/index.js';

export const listProducts = async (req, res, next) => {
  try {
    const items = await Product.findAll({ include: [{ model: Supplier, as: 'supplier' }] });
    res.json(items);
  } catch (err) { next(err); }
};

export const createProduct = async (req, res, next) => {
  try {
    const item = await Product.create(req.body);
    res.status(201).json(item);
  } catch (err) { next(err); }
};

export const updateProduct = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [count] = await Product.update(req.body, { where: { id } });
    if (!count) return res.status(404).json({ message: 'Not found' });
    const item = await Product.findByPk(id);
    res.json(item);
  } catch (err) { next(err); }
};

export const deleteProduct = async (req, res, next) => {
  try {
    const id = req.params.id;
    const count = await Product.destroy({ where: { id } });
    if (!count) return res.status(404).json({ message: 'Not found' });
    res.status(204).end();
  } catch (err) { next(err); }
};


