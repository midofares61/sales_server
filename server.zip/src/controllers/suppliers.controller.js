import { Supplier } from '../models/index.js';

export const listSuppliers = async (req, res, next) => {
  try {
    const items = await Supplier.findAll();
    res.json(items);
  } catch (err) { next(err); }
};

export const createSupplier = async (req, res, next) => {
  try {
    const item = await Supplier.create(req.body);
    res.status(201).json(item);
  } catch (err) { next(err); }
};

export const updateSupplier = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [count] = await Supplier.update(req.body, { where: { id } });
    if (!count) return res.status(404).json({ message: 'Not found' });
    const item = await Supplier.findByPk(id);
    res.json(item);
  } catch (err) { next(err); }
};

export const deleteSupplier = async (req, res, next) => {
  try {
    const id = req.params.id;
    const count = await Supplier.destroy({ where: { id } });
    if (!count) return res.status(404).json({ message: 'Not found' });
    res.status(204).end();
  } catch (err) { next(err); }
};


