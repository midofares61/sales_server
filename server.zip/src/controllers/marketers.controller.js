import { Marketer } from '../models/index.js';

export const listMarketers = async (req, res, next) => {
  try { res.json(await Marketer.findAll()); } catch (e) { next(e); }
};
export const createMarketer = async (req, res, next) => {
  try { res.status(201).json(await Marketer.create(req.body)); } catch (e) { next(e); }
};
export const updateMarketer = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [c] = await Marketer.update(req.body, { where: { id } });
    if (!c) return res.status(404).json({ message: 'Not found' });
    res.json(await Marketer.findByPk(id));
  } catch (e) { next(e); }
};
export const deleteMarketer = async (req, res, next) => {
  try {
    const id = req.params.id;
    const c = await Marketer.destroy({ where: { id } });
    if (!c) return res.status(404).json({ message: 'Not found' });
    res.status(204).end();
  } catch (e) { next(e); }
};


