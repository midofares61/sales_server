import { sequelize, Order, OrderDetail, Product, Marketer, Mandobe } from '../models/index.js';

export const listOrders = async (req, res, next) => {
  try {
    const items = await Order.findAll({
      include: [
        { model: Mandobe, as: 'mandobeUser' },
        { model: Marketer, as: 'marketer' },
        { model: OrderDetail, as: 'details', include: [{ model: Product, as: 'product' }] }
      ],
      order: [['id', 'DESC']]
    });
    res.json(items);
  } catch (e) { next(e); }
};

export const createOrder = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const { details = [], ...orderData } = req.body;
    const order = await Order.create(orderData, { transaction: t });
    if (details.length) {
      const rows = details.map(d => ({ ...d, order_id: order.id }));
      await OrderDetail.bulkCreate(rows, { transaction: t });
    }
    await t.commit();
    req.io.emit('order:new', { id: order.id, order_code: order.order_code });
    const created = await Order.findByPk(order.id, {
      include: [
        { model: Mandobe, as: 'mandobeUser' },
        { model: Marketer, as: 'marketer' },
        { model: OrderDetail, as: 'details', include: [{ model: Product, as: 'product' }] }
      ]
    });
    res.status(201).json(created);
  } catch (e) {
    await t.rollback();
    next(e);
  }
};

export const updateOrder = async (req, res, next) => {
  const t = await sequelize.transaction();
  try {
    const id = req.params.id;
    const { details, ...orderData } = req.body;
    const [c] = await Order.update(orderData, { where: { id }, transaction: t });
    if (!c) { await t.rollback(); return res.status(404).json({ message: 'Not found' }); }
    if (Array.isArray(details)) {
      await OrderDetail.destroy({ where: { order_id: id }, transaction: t });
      const rows = details.map(d => ({ ...d, order_id: id }));
      if (rows.length) await OrderDetail.bulkCreate(rows, { transaction: t });
    }
    await t.commit();
    const updated = await Order.findByPk(id, {
      include: [
        { model: Mandobe, as: 'mandobeUser' },
        { model: Marketer, as: 'marketer' },
        { model: OrderDetail, as: 'details', include: [{ model: Product, as: 'product' }] }
      ]
    });
    res.json(updated);
  } catch (e) { await t.rollback(); next(e); }
};

export const deleteOrder = async (req, res, next) => {
  try {
    const id = req.params.id;
    const c = await Order.destroy({ where: { id } });
    if (!c) return res.status(404).json({ message: 'Not found' });
    res.status(204).end();
  } catch (e) { next(e); }
};


