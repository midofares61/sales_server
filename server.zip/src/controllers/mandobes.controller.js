import { Mandobe } from '../models/index.js';

export const listMandobes = async (req, res, next) => {
  try { res.json(await Mandobe.findAll()); } catch (e) { next(e); }
};
export const createMandobe = async (req, res, next) => {
  try { res.status(201).json(await Mandobe.create(req.body)); } catch (e) { next(e); }
};
export const updateMandobe = async (req, res, next) => {
  try {
    const id = req.params.id;
    const [c] = await Mandobe.update(req.body, { where: { id } });
    if (!c) return res.status(404).json({ message: 'Not found' });
    res.json(await Mandobe.findByPk(id));
  } catch (e) { next(e); }
};
export const deleteMandobe = async (req, res, next) => {
  try {
    const id = req.params.id;
    const c = await Mandobe.destroy({ where: { id } });
    if (!c) return res.status(404).json({ message: 'Not found' });
    res.status(204).end();
  } catch (e) { next(e); }
};


