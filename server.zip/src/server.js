import express from 'express';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import morgan from 'morgan';
import { env } from './config/index.js';
import router from './routes/index.js';
import { connectDatabase } from './models/index.js';
import { errorHandler } from './middlewares/errorHandler.js';

const app = express();
const server = http.createServer(app);
const io = new SocketIOServer(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Attach io to req for controllers to emit
app.use((req, res, next) => { req.io = io; next(); });

app.use('/api', router);

app.use(errorHandler);

io.on('connection', socket => {
  // eslint-disable-next-line no-console
  console.log('socket connected', socket.id);
});

const start = async () => {
  try {
    await connectDatabase();
    server.listen(env.port, () => {
      // eslint-disable-next-line no-console
      console.log(`Server listening on port ${env.port}`);
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('Failed to start server', err);
    process.exit(1);
  }
};

start();


